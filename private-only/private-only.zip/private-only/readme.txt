===Private Only===  
Contributors: katemag  
Donate Link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=L3J4LBDGP533Q   
Tags: private access, login, remove feed  
Requires at least: 3.0  
Tested up to: 3.9.1  
Stable tag: 3.5

Redirects all non-logged in users to login form.

==Description==  
Do you have a private blog that you only want your friends and family to see and read it?

This plugin will redirect all users who aren't logged in to the login form where they are shown a user-friendly message  

Requires WordPress 3.0 and PHP5

If you have suggestions for a new add-on, feel free to email me at studio[at]pixert.com. 

Become a fan of Pixel Insert/Pixert on Facebook! http://www.facebook.com/PixelInsert  or follow Pixel Insert/Pixert on Twitter! http://twitter.com/pixert

Follow our developer, Kate Mag on Twitter! http://twitter.com/katemag

Features:  
1. Redirect all non-logged in users to login form  
2. Custom Logo on Login Page. You can change WordPress Logo  
3. Sub plugin name Disable Feed that allow you to choose disable or enable feed.  
4. Single public page  
5. Localization  
6. Custom CSS                                              
7. Custom Logo Link and custom Logo height                                
8. Remove Register and Forgot Your Password? on WP-Admin login page   
9. Remove Back to Blog link on WP-Admin login page      
10. The plugin redirect logged-in users to Homepage     
11. Fix for shrink logo in WordPress 3.8  
12. Detect Search Engine Visibility settings          
13. Custom Login Message

==Installation==  
1. Download The Private Only package file, extract the private-only directory from ZIP file, upload it to WordPress Plugins directory '/wp-content/plugins/' or install plugin from Plugin panel in WordPress Dashboard  
2. Activate Private Only via Plugin page                 
3. Activate Disable Feed if you want to disable feed 
4. See Settings tab on WP Admin, look for Private Only Custom Login settings

If you are new to WordPress : http://codex.wordpress.org/Managing_Plugins#Installing_Plugins

==Screenshots==  
Screenshots are available at http://pixert.com/blog